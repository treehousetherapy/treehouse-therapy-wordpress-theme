<?php
/**
 * Template Name: Services Page
 * Treehouse Therapy Center - Services Page
 * Upstream Flow Design System
 */

get_header();
?>

<!-- Hero Section -->
<section class="hero-upstream" style="min-height: auto; padding: 8rem 2rem 4rem;">
    <div class="hero-bg-pattern"></div>

    <!-- Decorative elements -->
    <div class="hero-decor decor-cloud-1">
        <svg viewBox="0 0 120 60" fill="white" fill-opacity="0.9">
            <ellipse cx="30" cy="40" rx="25" ry="18"/>
            <ellipse cx="55" cy="35" rx="30" ry="22"/>
            <ellipse cx="85" cy="38" rx="22" ry="16"/>
        </svg>
    </div>

    <div class="hero-decor decor-leaf-1">
        <svg viewBox="0 0 60 80" fill="none">
            <path d="M30 5C45 20 50 45 45 65C40 75 30 80 30 80C30 80 20 75 15 65C10 45 15 20 30 5Z" fill="#FFC107" fill-opacity="0.8"/>
        </svg>
    </div>

    <div style="max-width: 900px; margin: 0 auto; text-align: center; position: relative; z-index: 10;" data-animate>
        <h1 style="color: var(--navy-deep); margin-bottom: 1.5rem;">
            ABA Services Built Around <span class="highlight-box">Your Child</span>
        </h1>
        <p style="font-size: 1.25rem; color: var(--text-medium); max-width: 700px; margin: 0 auto;">
            Every child is unique, and so is every plan. We create personalized ABA therapy that meets your child where they are and helps them grow at their own pace.
        </p>
    </div>
</section>

<!-- Wave Transition -->
<div class="wave-transition" style="background: #C5E6F3;">
    <svg viewBox="0 0 1440 100" preserveAspectRatio="none">
        <path d="M0,0 C360,100 1080,100 1440,0 L1440,100 L0,100 Z" fill="#F0F9FF"/>
    </svg>
</div>

<!-- Service Options Section -->
<section class="section-services">
    <div class="section-header" data-animate>
        <h2>Caring for a child with ASD is a journey and we're <span class="highlight-box highlight-pink">here with you</span> every step of the way.</h2>
    </div>

    <div style="max-width: 900px; margin: 3rem auto; display: grid; gap: 1.25rem;" data-stagger>
        <!-- Full Day, Home-Based -->
        <div class="service-option-card" data-animate>
            <div class="service-option-icon">
                <svg viewBox="0 0 48 48" fill="none">
                    <path d="M24 8L40 20V38H8V20L24 8Z" stroke="#5B6B9E" stroke-width="2.5" fill="none"/>
                    <rect x="18" y="28" width="12" height="10" fill="#5B6B9E"/>
                </svg>
            </div>
            <h3>Full Day, Home-Based</h3>
        </div>

        <!-- Before daycare/school -->
        <div class="service-option-card" data-animate>
            <div class="service-option-icon">
                <svg viewBox="0 0 48 48" fill="none">
                    <circle cx="24" cy="24" r="16" stroke="#5B6B9E" stroke-width="2.5" fill="none"/>
                    <path d="M24 24L24 14" stroke="#5B6B9E" stroke-width="2.5" stroke-linecap="round"/>
                    <path d="M24 24L30 18" stroke="#5B6B9E" stroke-width="2.5" stroke-linecap="round"/>
                </svg>
            </div>
            <h3>Before daycare/school</h3>
        </div>

        <!-- After daycare/school -->
        <div class="service-option-card" data-animate>
            <div class="service-option-icon">
                <svg viewBox="0 0 48 48" fill="none">
                    <rect x="10" y="14" width="28" height="22" stroke="#5B6B9E" stroke-width="2.5" fill="none" rx="2"/>
                    <path d="M16 14V10H32V14" stroke="#5B6B9E" stroke-width="2.5"/>
                    <rect x="14" y="20" width="6" height="6" fill="#5B6B9E" rx="1"/>
                    <rect x="28" y="20" width="6" height="6" fill="#5B6B9E" rx="1"/>
                </svg>
            </div>
            <h3>After daycare/school</h3>
        </div>

        <!-- During daycare/school -->
        <div class="service-option-card" data-animate>
            <div class="service-option-icon">
                <svg viewBox="0 0 48 48" fill="none">
                    <rect x="12" y="16" width="24" height="20" stroke="#5B6B9E" stroke-width="2.5" fill="none"/>
                    <rect x="20" y="28" width="8" height="8" fill="#5B6B9E"/>
                    <rect x="16" y="20" width="4" height="6" fill="none" stroke="#5B6B9E" stroke-width="1.5"/>
                    <rect x="22" y="20" width="4" height="6" fill="none" stroke="#5B6B9E" stroke-width="1.5"/>
                    <rect x="28" y="20" width="4" height="6" fill="none" stroke="#5B6B9E" stroke-width="1.5"/>
                    <path d="M24 10L30 16H18L24 10Z" fill="#5B6B9E"/>
                </svg>
            </div>
            <h3>During daycare/school</h3>
        </div>

        <!-- Weekends -->
        <div class="service-option-card" data-animate>
            <div class="service-option-icon">
                <svg viewBox="0 0 48 48" fill="none">
                    <rect x="10" y="12" width="28" height="26" stroke="#5B6B9E" stroke-width="2.5" fill="none" rx="2"/>
                    <line x1="10" y1="20" x2="38" y2="20" stroke="#5B6B9E" stroke-width="2.5"/>
                    <text x="22" y="18" fill="#5B6B9E" font-size="8" font-weight="600" font-family="Arial">Sa/Su</text>
                </svg>
            </div>
            <h3>Weekends</h3>
        </div>
    </div>

    <div style="text-align: center; margin-top: 3rem;" data-animate>
        <a href="<?php echo home_url('/contact'); ?>" class="btn btn-primary">
            Get Started Today
            <span class="btn-arrow">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                    <path d="M5 12h14M12 5l7 7-7 7"/>
                </svg>
            </span>
        </a>
    </div>
</section>

<!-- Wave Transition -->
<div class="wave-transition wave-transition-flip" style="background: white;">
    <svg viewBox="0 0 1440 100" preserveAspectRatio="none">
        <path d="M0,100 C480,0 960,0 1440,100 L1440,0 L0,0 Z" fill="#F0F9FF"/>
    </svg>
</div>

<!-- Who We Serve Section -->
<section class="section-skills">
    <div class="skills-container">
        <div class="skills-header" data-animate>
            <h2>Who We <span class="highlight-box">Serve</span></h2>
            <p>Supporting children and families across the autism spectrum</p>
        </div>

        <div class="skills-grid" data-stagger>
            <div class="skill-card" data-animate>
                <div class="skill-icon skill-icon-teal">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="8" r="5"/>
                        <path d="M3 21v-2a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4v2"/>
                    </svg>
                </div>
                <div class="skill-content">
                    <h4>Ages Birth - 21</h4>
                    <p>From early intervention through young adulthood</p>
                </div>
            </div>

            <div class="skill-card" data-animate>
                <div class="skill-icon skill-icon-pink">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                    </svg>
                </div>
                <div class="skill-content">
                    <h4>Autism Spectrum Disorder</h4>
                    <p>All levels and presentations of ASD</p>
                </div>
            </div>

            <div class="skill-card" data-animate>
                <div class="skill-icon skill-icon-yellow">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                        <circle cx="9" cy="7" r="4"/>
                        <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                    </svg>
                </div>
                <div class="skill-content">
                    <h4>Families</h4>
                    <p>Parent training and family support services</p>
                </div>
            </div>

            <div class="skill-card" data-animate>
                <div class="skill-icon skill-icon-coral">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
                        <polyline points="9 22 9 12 15 12 15 22"/>
                    </svg>
                </div>
                <div class="skill-content">
                    <h4>Home, School & Community</h4>
                    <p>Flexible service locations to meet your needs</p>
                </div>
            </div>

            <div class="skill-card" data-animate>
                <div class="skill-icon skill-icon-purple">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
                        <line x1="16" y1="2" x2="16" y2="6"/>
                        <line x1="8" y1="2" x2="8" y2="6"/>
                        <line x1="3" y1="10" x2="21" y2="10"/>
                    </svg>
                </div>
                <div class="skill-content">
                    <h4>Flexible Scheduling</h4>
                    <p>Sessions that work with your family's routine</p>
                </div>
            </div>

            <div class="skill-card" data-animate>
                <div class="skill-icon skill-icon-teal">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>
                    </svg>
                </div>
                <div class="skill-content">
                    <h4>Evidence-Based</h4>
                    <p>Scientifically proven ABA techniques and methods</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- What to Expect Section -->
<section class="section-aba-fun">
    <div class="aba-fun-container">
        <div class="aba-fun-header" data-animate>
            <h2>What You Can <span class="highlight-box highlight-pink">Expect</span></h2>
        </div>

        <div class="blob-container" data-animate>
            <div class="blob blob-pink">
                <div class="blob-shape"></div>
                <h4>Assessment</h4>
                <p>Comprehensive evaluation to understand your child's needs</p>
            </div>

            <div class="blob blob-yellow">
                <div class="blob-shape"></div>
                <h4>Custom Plan</h4>
                <p>Personalized goals designed just for your child</p>
            </div>

            <div class="blob blob-teal">
                <div class="blob-shape"></div>
                <h4>Progress</h4>
                <p>Regular updates and data tracking to show growth</p>
            </div>
        </div>
    </div>
</section>

<!-- Insurance Section -->
<section class="section-insurance">
    <div class="insurance-container">
        <div class="insurance-header" data-animate>
            <h2>Insurance & <span class="highlight-box">Funding</span></h2>
            <p>We work with most major insurance providers to make ABA therapy accessible</p>
        </div>

        <div class="insurance-grid" data-stagger>
            <span class="insurance-pill teal" data-animate>Blue Cross Blue Shield</span>
            <span class="insurance-pill pink" data-animate>Medicaid/MA</span>
            <span class="insurance-pill yellow" data-animate>HealthPartners</span>
            <span class="insurance-pill teal" data-animate>Aetna</span>
            <span class="insurance-pill pink" data-animate>Cigna</span>
            <span class="insurance-pill yellow" data-animate>UnitedHealthcare</span>
            <span class="insurance-pill teal" data-animate>Medica</span>
            <span class="insurance-pill pink" data-animate>UCare</span>
        </div>

        <div style="max-width: 700px; margin: 3rem auto 0; text-align: center;" data-animate>
            <p style="color: var(--text-medium); margin-bottom: 1rem;">
                We handle all the insurance verification and paperwork so you can focus on what matters most—your child.
            </p>
            <p style="color: var(--text-medium);">
                Don't see your insurance? <a href="<?php echo home_url('/contact'); ?>" style="color: var(--pop-pink); font-weight: 600; text-decoration: underline;">Contact us</a> - we may still be able to help!
            </p>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="section-process">
    <div class="process-header" data-animate>
        <h2>Ready to Get Started?</h2>
        <p>Let's talk about how we can support your child's growth</p>
    </div>

    <div style="text-align: center; margin-top: 2rem;" data-animate>
        <div style="display: flex; justify-content: center; gap: 1rem; flex-wrap: wrap;">
            <a href="<?php echo home_url('/contact'); ?>" class="btn btn-primary">
                Request a Consultation
                <span class="btn-arrow">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                        <path d="M5 12h14M12 5l7 7-7 7"/>
                    </svg>
                </span>
            </a>
            <a href="tel:6123094135" class="btn btn-secondary" style="background: white; color: var(--navy-deep);">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 20px; height: 20px;">
                    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/>
                </svg>
                Call Us: (612) 309-4135
            </a>
        </div>
    </div>
</section>

<?php get_footer(); ?>
