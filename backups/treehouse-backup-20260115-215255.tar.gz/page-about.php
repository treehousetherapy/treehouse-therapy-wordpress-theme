<?php
/**
 * Template Name: About Page
 * Treehouse Therapy Center - About Page
 * Upstream Flow Design System
 */

get_header();
?>

<!-- Hero Section -->
<section class="hero-upstream" style="min-height: auto; padding: 8rem 2rem 4rem;">
    <div class="hero-bg-pattern"></div>

    <!-- Decorative clouds -->
    <div class="hero-decor decor-cloud-1">
        <svg viewBox="0 0 120 60" fill="white" fill-opacity="0.9">
            <ellipse cx="30" cy="40" rx="25" ry="18"/>
            <ellipse cx="55" cy="35" rx="30" ry="22"/>
            <ellipse cx="85" cy="38" rx="22" ry="16"/>
        </svg>
    </div>

    <div style="max-width: 900px; margin: 0 auto; text-align: center; position: relative; z-index: 10;" data-animate>
        <h1 style="color: var(--navy-deep); margin-bottom: 1.5rem;">
            What is <span class="highlight-box">ABA Therapy?</span>
        </h1>
        <p style="font-size: 1.25rem; color: var(--text-medium); max-width: 700px; margin: 0 auto 1rem;">
            Applied Behavior Analysis (ABA) is a scientifically proven therapy that helps children with autism develop essential life skills through positive reinforcement and individualized learning strategies.
        </p>
        <p style="font-size: 1.1rem; color: var(--navy-deep); font-weight: 600;">
            Ages served: Birth through 21 years
        </p>
    </div>
</section>

<!-- Wave Transition -->
<div class="wave-transition" style="background: #C5E6F3;">
    <svg viewBox="0 0 1440 100" preserveAspectRatio="none">
        <path d="M0,0 C360,100 1080,100 1440,0 L1440,100 L0,100 Z" fill="#F0F9FF"/>
    </svg>
</div>

<!-- Benefits Section -->
<section class="section-services">
    <div class="section-header" data-animate>
        <h2>How ABA <span class="highlight-box highlight-pink">Helps</span></h2>
        <p>Evidence-based therapy that makes a real difference</p>
    </div>

    <div class="services-grid" data-stagger>
        <div class="service-card" data-animate>
            <div class="service-illustration">
                <svg viewBox="0 0 160 140" fill="none">
                    <circle cx="80" cy="60" r="40" fill="#E8F6F5"/>
                    <circle cx="80" cy="60" r="40" stroke="#2AA198" stroke-width="3"/>
                    <path d="M60 60 L75 75 L100 50" stroke="#2AA198" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
                    <circle cx="80" cy="110" r="15" fill="#FFC107"/>
                    <path d="M75 105 L80 115 L90 100" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </div>
            <h3>Building Essential Skills</h3>
            <p>Developing communication, social, and daily living skills that last a lifetime through fun, engaging activities.</p>
        </div>

        <div class="service-card" data-animate>
            <div class="service-illustration">
                <svg viewBox="0 0 160 140" fill="none">
                    <path d="M80 30 L100 50 L95 80 L65 80 L60 50 Z" fill="#E8F6F5" stroke="#E91E8C" stroke-width="3"/>
                    <circle cx="80" cy="55" r="8" fill="#E91E8C"/>
                    <path d="M40 90 L80 110 L120 90" stroke="#FFC107" stroke-width="4" stroke-linecap="round"/>
                    <circle cx="40" cy="90" r="8" fill="#FFC107"/>
                    <circle cx="120" cy="90" r="8" fill="#FFC107"/>
                </svg>
            </div>
            <h3>Positive Reinforcement</h3>
            <p>Encouraging growth through meaningful rewards and celebrating every milestone along the way.</p>
        </div>

        <div class="service-card" data-animate>
            <div class="service-illustration">
                <svg viewBox="0 0 160 140" fill="none">
                    <circle cx="60" cy="50" r="20" fill="#E8F6F5" stroke="#2AA198" stroke-width="3"/>
                    <circle cx="100" cy="50" r="20" fill="#E8F6F5" stroke="#2AA198" stroke-width="3"/>
                    <circle cx="80" cy="90" r="20" fill="#E8F6F5" stroke="#2AA198" stroke-width="3"/>
                    <path d="M70 55 Q80 70 90 55" stroke="#E91E8C" stroke-width="3" stroke-linecap="round"/>
                    <circle cx="55" cy="47" r="3" fill="#1E3A5F"/>
                    <circle cx="65" cy="47" r="3" fill="#1E3A5F"/>
                    <circle cx="95" cy="47" r="3" fill="#1E3A5F"/>
                    <circle cx="105" cy="47" r="3" fill="#1E3A5F"/>
                </svg>
            </div>
            <h3>Connecting & Communicating</h3>
            <p>Helping children express themselves and build meaningful relationships with family and friends.</p>
        </div>
    </div>
</section>

<!-- Philosophy Section -->
<section class="section-skills">
    <div class="skills-container">
        <div class="skills-header" data-animate>
            <h2>Our <span class="highlight-box">Philosophy</span></h2>
            <p>Every child deserves to feel confident, capable, and connected</p>
        </div>

        <div class="skills-grid" data-stagger>
            <div class="skill-card" data-animate>
                <div class="skill-icon skill-icon-yellow">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="8" r="5"/>
                        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                    </svg>
                </div>
                <div class="skill-content">
                    <h4>The Child is the Champion</h4>
                    <p>Every session is designed around their unique strengths and interests</p>
                </div>
            </div>

            <div class="skill-card" data-animate>
                <div class="skill-icon skill-icon-teal">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                        <circle cx="9" cy="7" r="4"/>
                        <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                    </svg>
                </div>
                <div class="skill-content">
                    <h4>We're Partners, Not Directors</h4>
                    <p>We work alongside your family to create meaningful change</p>
                </div>
            </div>

            <div class="skill-card" data-animate>
                <div class="skill-icon skill-icon-pink">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                    </svg>
                </div>
                <div class="skill-content">
                    <h4>Every Child Deserves Joy</h4>
                    <p>Dignity, happiness, and a sense of belonging are what we work toward</p>
                </div>
            </div>

            <div class="skill-card" data-animate>
                <div class="skill-icon skill-icon-coral">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
                    </svg>
                </div>
                <div class="skill-content">
                    <h4>Progress Over Perfection</h4>
                    <p>We celebrate small wins and growth at every step</p>
                </div>
            </div>

            <div class="skill-card" data-animate>
                <div class="skill-icon skill-icon-purple">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                        <polyline points="22 4 12 14.01 9 11.01"/>
                    </svg>
                </div>
                <div class="skill-content">
                    <h4>Data-Driven Decisions</h4>
                    <p>We track progress with real data so you can see growth happening</p>
                </div>
            </div>

            <div class="skill-card" data-animate>
                <div class="skill-icon skill-icon-teal">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
                        <polyline points="9 22 9 12 15 12 15 22"/>
                    </svg>
                </div>
                <div class="skill-content">
                    <h4>Therapy Where You Are</h4>
                    <p>In your home, at school, or in the community</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ABA Made Fun -->
<section class="section-aba-fun">
    <div class="aba-fun-container">
        <div class="aba-fun-header" data-animate>
            <h2>You're Choosing a Partner Who...</h2>
        </div>

        <div class="blob-container" data-animate>
            <div class="blob blob-pink">
                <div class="blob-shape"></div>
                <h4>Listens</h4>
                <p>We hear your concerns and your child's needs</p>
            </div>

            <div class="blob blob-yellow">
                <div class="blob-shape"></div>
                <h4>Adapts</h4>
                <p>Strategies adjust as your child grows</p>
            </div>

            <div class="blob blob-teal">
                <div class="blob-shape"></div>
                <h4>Celebrates</h4>
                <p>Every milestone matters to us</p>
            </div>
        </div>
    </div>
</section>

<!-- Service Areas CTA -->
<section class="section-process">
    <div class="process-header" data-animate>
        <h2>Serving the Greater Twin Cities</h2>
        <p>In-home ABA services throughout the Minneapolis-St. Paul metro area</p>
    </div>

    <div style="max-width: 900px; margin: 0 auto; display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 1rem; text-align: center;" data-stagger>
        <div style="background: rgba(30, 58, 95, 0.85); padding: 1.25rem; border-radius: 12px; border: 2px solid rgba(255,255,255,0.3);" data-animate>
            <p style="color: white; font-weight: 700; font-size: 1.05rem;">Minneapolis</p>
        </div>
        <div style="background: rgba(30, 58, 95, 0.85); padding: 1.25rem; border-radius: 12px; border: 2px solid rgba(255,255,255,0.3);" data-animate>
            <p style="color: white; font-weight: 700; font-size: 1.05rem;">St. Paul</p>
        </div>
        <div style="background: rgba(30, 58, 95, 0.85); padding: 1.25rem; border-radius: 12px; border: 2px solid rgba(255,255,255,0.3);" data-animate>
            <p style="color: white; font-weight: 700; font-size: 1.05rem;">Bloomington</p>
        </div>
        <div style="background: rgba(30, 58, 95, 0.85); padding: 1.25rem; border-radius: 12px; border: 2px solid rgba(255,255,255,0.3);" data-animate>
            <p style="color: white; font-weight: 700; font-size: 1.05rem;">Eagan</p>
        </div>
        <div style="background: rgba(30, 58, 95, 0.85); padding: 1.25rem; border-radius: 12px; border: 2px solid rgba(255,255,255,0.3);" data-animate>
            <p style="color: white; font-weight: 700; font-size: 1.05rem;">Apple Valley</p>
        </div>
        <div style="background: rgba(30, 58, 95, 0.85); padding: 1.25rem; border-radius: 12px; border: 2px solid rgba(255,255,255,0.3);" data-animate>
            <p style="color: white; font-weight: 700; font-size: 1.05rem;">Lakeville</p>
        </div>
        <div style="background: rgba(30, 58, 95, 0.85); padding: 1.25rem; border-radius: 12px; border: 2px solid rgba(255,255,255,0.3);" data-animate>
            <p style="color: white; font-weight: 700; font-size: 1.05rem;">Burnsville</p>
        </div>
        <div style="background: rgba(30, 58, 95, 0.85); padding: 1.25rem; border-radius: 12px; border: 2px solid rgba(255,255,255,0.3);" data-animate>
            <p style="color: white; font-weight: 700; font-size: 1.05rem;">Edina</p>
        </div>
        <div style="background: rgba(30, 58, 95, 0.85); padding: 1.25rem; border-radius: 12px; border: 2px solid rgba(255,255,255,0.3);" data-animate>
            <p style="color: white; font-weight: 700; font-size: 1.05rem;">Eden Prairie</p>
        </div>
        <div style="background: rgba(30, 58, 95, 0.85); padding: 1.25rem; border-radius: 12px; border: 2px solid rgba(255,255,255,0.3);" data-animate>
            <p style="color: white; font-weight: 700; font-size: 1.05rem;">Minnetonka</p>
        </div>
        <div style="background: rgba(30, 58, 95, 0.85); padding: 1.25rem; border-radius: 12px; border: 2px solid rgba(255,255,255,0.3);" data-animate>
            <p style="color: white; font-weight: 700; font-size: 1.05rem;">Plymouth</p>
        </div>
        <div style="background: rgba(30, 58, 95, 0.85); padding: 1.25rem; border-radius: 12px; border: 2px solid rgba(255,255,255,0.3);" data-animate>
            <p style="color: white; font-weight: 700; font-size: 1.05rem;">Maple Grove</p>
        </div>
        <div style="background: rgba(30, 58, 95, 0.85); padding: 1.25rem; border-radius: 12px; border: 2px solid rgba(255,255,255,0.3);" data-animate>
            <p style="color: white; font-weight: 700; font-size: 1.05rem;">Shakopee</p>
        </div>
        <div style="background: rgba(30, 58, 95, 0.85); padding: 1.25rem; border-radius: 12px; border: 2px solid rgba(255,255,255,0.3);" data-animate>
            <p style="color: white; font-weight: 700; font-size: 1.05rem;">Woodbury</p>
        </div>
        <div style="background: rgba(30, 58, 95, 0.85); padding: 1.25rem; border-radius: 12px; border: 2px solid rgba(255,255,255,0.3);" data-animate>
            <p style="color: white; font-weight: 700; font-size: 1.05rem;">Roseville</p>
        </div>
    </div>

    <div style="text-align: center; margin-top: 2rem;" data-animate>
        <a href="<?php echo home_url('/contact'); ?>" class="btn btn-primary">
            Get Started Today
            <span class="btn-arrow">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                    <path d="M5 12h14M12 5l7 7-7 7"/>
                </svg>
            </span>
        </a>
    </div>
</section>

<!-- Wave to Contact -->
<div class="wave-transition" style="background: linear-gradient(180deg, #2AA198 0%, #4ECDC4 100%);">
    <svg viewBox="0 0 1440 100" preserveAspectRatio="none">
        <path d="M0,50 Q360,100 720,50 T1440,50 L1440,100 L0,100 Z" fill="#F0F9FF"/>
    </svg>
</div>

<!-- Contact Section -->
<section class="section-contact">
    <div class="contact-container">
        <div class="contact-form-wrapper" data-animate>
            <h3>Request a Consultation</h3>
            <form action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" method="POST">
                <input type="hidden" name="action" value="submit_contact_form">

                <div class="form-row">
                    <div class="form-group">
                        <label>First Name*</label>
                        <input type="text" name="first_name" placeholder="Jane" required>
                    </div>
                    <div class="form-group">
                        <label>Last Name*</label>
                        <input type="text" name="last_name" placeholder="Doe" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Phone*</label>
                        <input type="tel" name="phone" placeholder="(555) 123-4567" required>
                    </div>
                    <div class="form-group">
                        <label>Email*</label>
                        <input type="email" name="email" placeholder="jane@example.com" required>
                    </div>
                </div>

                <div class="form-group">
                    <label>Insurance Provider</label>
                    <input type="text" name="insurance" placeholder="e.g. Blue Cross Blue Shield">
                </div>

                <div class="form-group">
                    <label>Message</label>
                    <textarea name="message" placeholder="Tell us about your child..."></textarea>
                </div>

                <button type="submit" class="btn btn-primary" style="width: 100%;">
                    Send Message
                    <span class="btn-arrow">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                            <path d="M5 12h14M12 5l7 7-7 7"/>
                        </svg>
                    </span>
                </button>
            </form>
        </div>

        <div class="contact-info-panel" data-animate>
            <h3>Let's talk about your child's journey</h3>
            <p>We're here to answer questions and help you get started.</p>

            <div class="contact-item">
                <div class="contact-item-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/>
                    </svg>
                </div>
                <a href="tel:6123094135">(612) 309-4135</a>
            </div>

            <div class="contact-item">
                <div class="contact-item-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                        <polyline points="22,6 12,13 2,6"/>
                    </svg>
                </div>
                <a href="mailto:info@treehousetherapymn.com">info@treehousetherapymn.com</a>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>
