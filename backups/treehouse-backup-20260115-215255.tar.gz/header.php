<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Upstream Flow Design System Styles -->
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/upstream-style.css" />
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- Header -->
<header class="site-header">
    <div class="header-inner">
        <!-- Logo -->
        <a href="<?php echo esc_url(home_url('/')); ?>" class="logo">
            <div class="logo-icon">
                <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <!-- Treehouse Icon -->
                    <circle cx="24" cy="24" r="22" fill="#2AA198"/>
                    <path d="M14 32V24L24 16L34 24V32" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                    <rect x="20" y="26" width="8" height="6" fill="white" rx="1"/>
                    <circle cx="24" cy="12" r="4" fill="#FFC107"/>
                    <path d="M10 20C12 18 16 17 20 18" stroke="#5FCFC3" stroke-width="2" stroke-linecap="round"/>
                    <path d="M38 20C36 18 32 17 28 18" stroke="#5FCFC3" stroke-width="2" stroke-linecap="round"/>
                </svg>
            </div>
            <div>
                <span class="logo-text">Treehouse Therapy</span>
                <span class="logo-tagline">Where progress flows</span>
            </div>
        </a>

        <!-- Desktop Navigation -->
        <nav class="nav-main">
            <a href="<?php echo home_url('/'); ?>" class="nav-link">Home</a>
            <a href="<?php echo home_url('/about'); ?>" class="nav-link">About</a>
            <a href="<?php echo home_url('/services'); ?>" class="nav-link">Services</a>
            <a href="<?php echo home_url('/careers'); ?>" class="nav-link">Careers</a>
            <a href="<?php echo home_url('/contact'); ?>" class="nav-link">Contact</a>
        </nav>

        <!-- CTA Buttons -->
        <div class="header-cta">
            <a href="tel:6123094135" class="btn-phone">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
                </svg>
                (612) 309-4135
            </a>
            <a href="<?php echo home_url('/contact'); ?>" class="btn-contact">
                Contact Us
                <span class="arrow">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M5 12h14M12 5l7 7-7 7"/>
                    </svg>
                </span>
            </a>
        </div>

        <!-- Mobile Menu Button -->
        <button onclick="toggleMenu()" class="mobile-menu-btn" aria-label="Toggle menu">
            <svg class="menu-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M4 6h16M4 12h16M4 18h16"/>
            </svg>
        </button>
    </div>

    <!-- Mobile Menu -->
    <div id="mobileMenu" class="mobile-menu">
        <nav class="mobile-nav">
            <a href="<?php echo home_url('/'); ?>" class="mobile-nav-link">Home</a>
            <a href="<?php echo home_url('/about'); ?>" class="mobile-nav-link">About</a>
            <a href="<?php echo home_url('/services'); ?>" class="mobile-nav-link">Services</a>
            <a href="<?php echo home_url('/careers'); ?>" class="mobile-nav-link">Careers</a>
            <a href="<?php echo home_url('/contact'); ?>" class="mobile-nav-link">Contact</a>
            <a href="tel:6123094135" class="btn btn-pink mobile-cta">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20">
                    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
                </svg>
                Call Us
            </a>
        </nav>
    </div>
</header>

<!-- Main Content -->
<main>
